package com.mirzecatafa.tiertagger;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class TierDataManager {
    public static final TierDataManager INSTANCE = new TierDataManager();
    private static final Logger LOGGER = LoggerFactory.getLogger("TierTagger/Data");
    private static final Gson GSON = new Gson();

    /** Custom bitmap font identifier */
    private static final Identifier KITS_FONT = new Identifier("tiertagger", "kits");

    /** Kit name -> Unicode private-use character (matches kits.json font provider) */
    private static final Map<String, String> KIT_CHARS = new HashMap<>();
    static {
        KIT_CHARS.put("sword",   "\uE001");
        KIT_CHARS.put("axe",     "\uE002");
        KIT_CHARS.put("uhc",     "\uE003");
        KIT_CHARS.put("nethpot", "\uE004");
        KIT_CHARS.put("crystal", "\uE005");
        KIT_CHARS.put("mace",    "\uE006");
        KIT_CHARS.put("potion",  "\uE007");
        KIT_CHARS.put("smp",     "\uE008");
    }

    /** username -> (kit -> tier) */
    private Map<String, Map<String, String>> tierData = new HashMap<>();

    /** The kit whose tier is currently being displayed. Null = show nothing. */
    private String selectedKit = null;

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private TierDataManager() {}

    // ── Selected kit ──────────────────────────────────────────────────────────

    public String getSelectedKit() { return selectedKit; }

    public void setSelectedKit(String kit) {
        this.selectedKit = kit;
        LOGGER.info("Selected kit: {}", kit);
    }

    public void clearSelectedKit() {
        this.selectedKit = null;
        LOGGER.info("Cleared kit selection");
    }

    public boolean hasSelectedKit() { return selectedKit != null; }

    // ── Tier access ───────────────────────────────────────────────────────────

    public String getTier(String username, String kit) {
        Map<String, String> kits = tierData.get(username);
        if (kits == null) {
            for (Map.Entry<String, Map<String, String>> entry : tierData.entrySet()) {
                if (entry.getKey().equalsIgnoreCase(username)) {
                    kits = entry.getValue();
                    break;
                }
            }
        }
        if (kits == null) return null;
        return kits.get(kit);
    }

    /**
     * Builds the nametag Text for a player given the currently selected kit.
     * Format:  [icon] TIER | username
     *
     * The icon is rendered via the custom "tiertagger:kits" bitmap font —
     * it appears as the actual PNG texture inside the nametag.
     */
    public Text buildNametagText(String username, String tier, String kit) {
        String ch = KIT_CHARS.get(kit);

        // Icon part — uses custom bitmap font so it renders as the actual icon PNG
        Text iconText = ch != null
                ? Text.literal(ch + " ").setStyle(Style.EMPTY.withFont(KITS_FONT))
                : Text.empty();

        // Tier + name part — uses default font
        Text labelText = Text.literal(tier + " | " + username);

        return iconText.copy().append(labelText);
    }

    // ── API Fetching ──────────────────────────────────────────────────────────

    public CompletableFuture<Void> fetchAllTiers() {
        String url = TierConfig.getInstance().apiBaseUrl + "/api/tier/all";
        LOGGER.info("Fetching tier data from {}", url);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Accept", "application/json")
                .GET()
                .build();

        return http.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() == 200) {
                        Type mapType = new TypeToken<Map<String, Map<String, String>>>() {}.getType();
                        Map<String, Map<String, String>> data = GSON.fromJson(response.body(), mapType);
                        if (data != null) {
                            tierData = data;
                            LOGGER.info("Loaded {} players from API", data.size());
                        }
                    } else {
                        LOGGER.warn("API returned status {}", response.statusCode());
                    }
                })
                .exceptionally(ex -> {
                    LOGGER.error("Failed to fetch tier data: {}", ex.getMessage());
                    return null;
                });
    }
}
