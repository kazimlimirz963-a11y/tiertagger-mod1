package com.mirzecatafa.tiertagger.command;

import com.mirzecatafa.tiertagger.TierDataManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class KitCommand {

    private static final List<String> VALID_KITS = Arrays.asList(
            "sword", "axe", "uhc", "nethpot", "crystal", "mace", "potion", "smp"
    );

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                ClientCommandManager.literal("kit")
                    .executes(ctx -> {
                        // /kit with no args — show current kit
                        String current = TierDataManager.INSTANCE.getSelectedKit();
                        if (current == null) {
                            ctx.getSource().sendFeedback(
                                Text.of("§7[TierTagger] No kit selected. Use /kit <kit>")
                            );
                        } else {
                            ctx.getSource().sendFeedback(
                                Text.of("§7[TierTagger] Current kit: §f" + current)
                            );
                        }
                        return 1;
                    })
                    .then(
                        ClientCommandManager.argument("kit_name", StringArgumentType.word())
                            .suggests(KIT_SUGGESTIONS)
                            .executes(ctx -> selectKit(ctx))
                    )
            );

            // /tiertagger refresh — manually refresh tier data
            dispatcher.register(
                ClientCommandManager.literal("tiertagger")
                    .then(
                        ClientCommandManager.literal("refresh")
                            .executes(ctx -> {
                                ctx.getSource().sendFeedback(
                                    Text.of("§7[TierTagger] Refreshing tier data...")
                                );
                                TierDataManager.INSTANCE.fetchAllTiers().thenRun(() -> {
                                    ctx.getSource().sendFeedback(
                                        Text.of("§7[TierTagger] Tier data refreshed!")
                                    );
                                });
                                return 1;
                            })
                    )
                    .then(
                        ClientCommandManager.literal("clear")
                            .executes(ctx -> {
                                TierDataManager.INSTANCE.clearSelectedKit();
                                ctx.getSource().sendFeedback(
                                    Text.of("§7[TierTagger] Kit selection cleared.")
                                );
                                return 1;
                            })
                    )
            );
        });
    }

    private static int selectKit(CommandContext<FabricClientCommandSource> ctx) {
        String kit = StringArgumentType.getString(ctx, "kit_name").toLowerCase();

        if (!VALID_KITS.contains(kit)) {
            ctx.getSource().sendError(
                Text.of("§c[TierTagger] Unknown kit: " + kit +
                        ". Valid: " + String.join(", ", VALID_KITS))
            );
            return 0;
        }

        TierDataManager.INSTANCE.setSelectedKit(kit);
        ctx.getSource().sendFeedback(
            Text.of("§7[TierTagger] Now showing §f" + kit + " §7tiers above players.")
        );
        return 1;
    }

    private static final SuggestionProvider<FabricClientCommandSource> KIT_SUGGESTIONS =
            (context, builder) -> {
                VALID_KITS.forEach(builder::suggest);
                return builder.buildFuture();
            };
}
