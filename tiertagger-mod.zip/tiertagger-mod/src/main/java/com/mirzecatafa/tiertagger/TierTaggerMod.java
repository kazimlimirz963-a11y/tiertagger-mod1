package com.mirzecatafa.tiertagger;

import com.mirzecatafa.tiertagger.command.KitCommand;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class TierTaggerMod implements ClientModInitializer {

    public static final String MOD_ID = "tiertagger";
    public static final Logger LOGGER = LoggerFactory.getLogger("TierTagger");

    @Override
    public void onInitializeClient() {
        LOGGER.info("TierTagger initializing...");

        // Load config (creates tiertagger.json if missing)
        TierConfig config = TierConfig.getInstance();
        LOGGER.info("API base URL: {}", config.apiBaseUrl);

        // Register /kit command
        KitCommand.register();

        // Fetch tier data when joining a world / server
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            LOGGER.info("Joined server — fetching tier data from API...");
            TierDataManager.INSTANCE.fetchAllTiers();
        });

        // Clear kit selection when leaving a world
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            TierDataManager.INSTANCE.clearSelectedKit();
            LOGGER.info("Disconnected — cleared kit selection.");
        });

        LOGGER.info("TierTagger ready! Use /kit <kitname> in-game.");
    }
}
