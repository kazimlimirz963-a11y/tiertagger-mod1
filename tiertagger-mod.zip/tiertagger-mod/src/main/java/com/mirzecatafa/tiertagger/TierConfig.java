package com.mirzecatafa.tiertagger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class TierConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("TierTagger/Config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FILENAME = "tiertagger.json";

    public String apiBaseUrl = "https://YOUR-REPLIT-URL.replit.app";

    private static TierConfig instance;

    public static TierConfig getInstance() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static TierConfig load() {
        Path configDir = FabricLoader.getInstance().getConfigDir();
        Path configFile = configDir.resolve(CONFIG_FILENAME);

        if (Files.exists(configFile)) {
            try (Reader reader = Files.newBufferedReader(configFile)) {
                TierConfig config = GSON.fromJson(reader, TierConfig.class);
                if (config != null) {
                    LOGGER.info("Loaded config: apiBaseUrl={}", config.apiBaseUrl);
                    return config;
                }
            } catch (IOException e) {
                LOGGER.error("Failed to read config file, using defaults", e);
            }
        }

        // Save default config
        TierConfig defaults = new TierConfig();
        defaults.save(configFile);
        LOGGER.info("Created default config at {}", configFile);
        LOGGER.warn("Edit '{}' and set your apiBaseUrl, then restart.", configFile);
        return defaults;
    }

    public void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            try (Writer writer = Files.newBufferedWriter(file)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to save config", e);
        }
    }
}
