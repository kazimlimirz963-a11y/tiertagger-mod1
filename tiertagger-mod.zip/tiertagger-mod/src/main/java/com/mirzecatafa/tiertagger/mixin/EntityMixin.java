package com.mirzecatafa.tiertagger.mixin;

import com.mirzecatafa.tiertagger.TierDataManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {

    /**
     * Replaces the player's nametag text with:
     *   [kit icon PNG]  TIER | username
     *
     * The icon is rendered using the custom "tiertagger:kits" bitmap font
     * defined in assets/tiertagger/font/kits.json — each kit maps to one of the
     * provided PNG textures via a Unicode private-use character.
     *
     * Only fires when a kit is selected via /kit command.
     */
    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void tiertagger$modifyDisplayName(CallbackInfoReturnable<Text> cir) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof AbstractClientPlayerEntity player)) return;

        TierDataManager manager = TierDataManager.INSTANCE;
        if (!manager.hasSelectedKit()) return;

        String selectedKit = manager.getSelectedKit();
        String username = player.getGameProfile().getName();
        String tier = manager.getTier(username, selectedKit);

        if (tier == null) return; // player has no tier for this kit — show vanilla name

        cir.setReturnValue(manager.buildNametagText(username, tier, selectedKit));
    }
}
